import { UserRound } from "lucide-react";
import { Link } from "react-router-dom";

export default function PortfolioHeader({ portfolio, username, isOwnPortfolio = false }) {
  const displayName = portfolio?.displayName || username || "Unnamed User";

  const headline =
    portfolio?.headline ||
    [portfolio?.currentRole, portfolio?.careerGoal].filter(Boolean).join(" | ") ||
    "Developer Portfolio";

  const coverImageUrl = portfolio?.coverImageUrl;
  const avatarUrl = portfolio?.avatarUrl;

  return (
    <section className="relative rounded-lg border border-[#B9D8CC] bg-white shadow-[0_18px_50px_rgba(31,111,95,0.10)]">
      <div className="relative z-0 h-52 overflow-hidden rounded-t-lg bg-[#1F6F5F] sm:h-60">
        {coverImageUrl ? (
          <img
            src={coverImageUrl}
            alt={`${displayName} cover`}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="grid h-full grid-rows-3">
            <div className="bg-[#1F6F5F]" />
            <div className="bg-[#2FA084]" />
            <div className="bg-[#6FCF97]" />
          </div>
        )}
      </div>

      <div className="relative z-10 flex flex-col gap-4 px-5 pb-6 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex min-w-0 items-end gap-4">
          <div className="-mt-20 h-24 w-24 shrink-0 overflow-hidden rounded-lg border-4 border-white bg-white shadow-[0_16px_34px_rgba(31,111,95,0.22)] ring-1 ring-[#B9D8CC] sm:-mt-24 sm:h-28 sm:w-28">
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt={displayName}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-[#EEEEEE] text-[#1F6F5F]">
                <UserRound size={42} />
              </div>
            )}
          </div>

          <div className="min-w-0 pb-1 pt-3">
            {isOwnPortfolio && (
              <div className="mb-2 flex flex-wrap gap-2">
                <span className="rounded-lg bg-[#1F6F5F] px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-[0.14em] text-white">
                  Private preview
                </span>
                <span className="rounded-lg border border-[#B9D8CC] bg-[#EAF8F1] px-2 py-0.5 text-[9px] font-extrabold uppercase tracking-[0.14em] text-[#1F6F5F]">
                  {portfolio?.isPublic ? "Public" : "Private"}
                </span>
              </div>
            )}

            <h1 className="truncate text-2xl font-extrabold tracking-tight text-[#18332D] sm:text-3xl">
              {displayName}
            </h1>

            <p className="mt-1 truncate text-sm font-bold text-slate-700">
              {headline}
            </p>
          </div>
        </div>

        {isOwnPortfolio && (
          <Link
            to="/portfolio/edit"
            className="inline-flex shrink-0 items-center justify-center rounded-lg bg-[#18332D] px-5 py-3 text-sm font-extrabold text-white no-underline shadow-[0_12px_28px_rgba(24,51,45,0.18)] transition hover:-translate-y-0.5 hover:bg-[#1F6F5F]"
          >
            Edit portfolio
          </Link>
        )}
      </div>
    </section>
  );
}
