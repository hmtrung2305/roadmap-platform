import { Handle, Position } from "@xyflow/react";
import {
  NODE_WIDTH,
  NODE_HEIGHT,
  formatSelectionText,
  getNodeTypeClass,
  getStatusColor,
} from "./roadmapUtils";

const handleClass = "!h-2 !w-2 !border-2 !border-[#B9D8CC] !bg-white";

const statusNodeClassMap = {
  completed: "border-[#111827] bg-[#D1D5DB] text-[#111827] hover:bg-[#D1D5DB]",
  in_progress: "border-[#03A791] bg-[#E9F5BE] text-[#18332D] hover:bg-[#E0F0AA]",
  locked: "border-slate-300 bg-slate-100 text-slate-500 opacity-85 hover:bg-slate-100",
  skipped: "border-slate-300 bg-slate-50 text-slate-500 opacity-90 hover:bg-slate-50",
};

function getStatusNodeClass(status) {
  return statusNodeClassMap[status] || "border-[#B9D8CC]";
}

export default function RoadmapFlowNode({ data }) {
  const status = data.status || "pending";
  const isCompleted = status === "completed";
  const isLocked = status === "locked";

  return (
    <button
      type="button"
      className={[
        "group relative flex cursor-pointer flex-col items-center justify-center gap-1 overflow-hidden rounded-lg border px-4 py-3 text-center shadow-sm outline-none transition-colors duration-150 focus-visible:ring-4 focus-visible:ring-[#81E7AF]/35",
        getNodeTypeClass(data.nodeType, data.checkpointType),
        getStatusNodeClass(status),
        data.isSelected ? "outline outline-4 outline-[#81E7AF]/50" : "",
      ].join(" ")}
      style={{ width: NODE_WIDTH, height: NODE_HEIGHT }}
    >
      <Handle id="top-target" type="target" position={Position.Top} className={handleClass} />
      <Handle id="top-source" type="source" position={Position.Top} className={handleClass} />
      <Handle id="bottom-target" type="target" position={Position.Bottom} className={handleClass} />
      <Handle id="bottom-source" type="source" position={Position.Bottom} className={handleClass} />
      <Handle id="left-target" type="target" position={Position.Left} className={handleClass} />
      <Handle id="left-source" type="source" position={Position.Left} className={handleClass} />
      <Handle id="right-target" type="target" position={Position.Right} className={handleClass} />
      <Handle id="right-source" type="source" position={Position.Right} className={handleClass} />

      <span
        className="absolute left-2 top-1.5 h-2.5 w-2.5 rounded-lg border border-white/80"
        style={{ background: getStatusColor(status, data.nodeType) }}
      />

      {isLocked && (
        <span
          className="absolute right-2 top-1 text-xs font-black text-slate-500"
          title="Locked"
        >
          🔒
        </span>
      )}

      <span
        className={[
          "line-clamp-3 max-w-full !text-[18px] font-black leading-4 tracking-tight sm:text-sm sm:leading-5",
          isCompleted ? "line-through decoration-[#111827] decoration-2" : "",
        ].join(" ")}
      >
        {data.title}
      </span>

      {data.nodeType === "choice_group" && (
        <span className="rounded-lg border border-[#B9D8CC] bg-white/95 px-2 py-0.5 text-[9px] font-extrabold tracking-[0.08em] text-[#18332D]">
          {formatSelectionText(data.selectionType, data.requiredCount)}
        </span>
      )}

      {data.nodeType === "checkpoint" && (
        <span className="rounded-lg border border-[#B9D8CC] bg-white/95 px-2 py-0.5 text-[9px] font-extrabold tracking-[0.08em] text-[#18332D]">
          {data.checkpointType || "checkpoint"}
        </span>
      )}
    </button>
  );
}
