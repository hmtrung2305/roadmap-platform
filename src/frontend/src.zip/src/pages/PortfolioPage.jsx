import { useEffect, useMemo, useState } from "react";
import { Globe2, Loader2, Mail, MapPin } from "lucide-react";
import { useParams } from "react-router-dom";
import { FaGithub, FaLinkedin } from "react-icons/fa";

import { getMyPortfolioApi, getPortfolioByUsernameApi } from "../api/portfolioApi";
import { useAuthStore } from "../stores/useAuthStore";
import PortfolioHeader from "../components/portfolio/PortfolioHeader";
import PortfolioStats from "../components/portfolio/PortfolioStats";
import PortfolioAbout from "../components/portfolio/PortfolioAbout";
import PortfolioRepositoryList from "../components/portfolio/PortfolioRepositoryList";
import PortfolioSkillGroups from "../components/portfolio/PortfolioSkillGroups";

export default function PortfolioPage() {
  const { username: routeUsername } = useParams();
  const user = useAuthStore((state) => state.user);

  const [portfolio, setPortfolio] = useState(null);
  const [portfolioLoading, setPortfolioLoading] = useState(true);
  const [portfolioError, setPortfolioError] = useState("");

  const isOwnPortfolio = !routeUsername;

  const username = useMemo(() => {
    return (
      routeUsername ||
      user?.username ||
      user?.userName ||
      user?.Username ||
      user?.email?.split("@")[0]
    );
  }, [routeUsername, user]);

  useEffect(() => {
    const fetchPortfolio = async () => {
      if (!isOwnPortfolio && !username) {
        setPortfolioLoading(false);
        setPortfolioError("Username was not found.");
        return;
      }

      try {
        setPortfolioLoading(true);
        setPortfolioError("");

        const data = isOwnPortfolio
          ? await getMyPortfolioApi()
          : await getPortfolioByUsernameApi(username);

        setPortfolio(data);
      } catch (error) {
        console.error("Load portfolio failed:", error);
        setPortfolioError(error?.message || "Could not load this portfolio.");
      } finally {
        setPortfolioLoading(false);
      }
    };

    fetchPortfolio();
  }, [username, isOwnPortfolio]);

  if (portfolioLoading) {
    return (
      <main className="min-h-[calc(100vh-4rem)] px-4 py-8 sm:px-6">
        <div className="mx-auto max-w-6xl rounded-lg border border-[#B9D8CC] bg-white p-6 shadow-[0_14px_34px_rgba(31,111,95,0.08)]">
          <div className="flex items-center gap-3 text-slate-600">
            <Loader2 className="animate-spin" size={18} />
            Loading portfolio...
          </div>
        </div>
      </main>
    );
  }

  if (portfolioError) {
    return (
      <main className="min-h-[calc(100vh-4rem)] px-4 py-8 sm:px-6">
        <section className="mx-auto max-w-3xl rounded-lg border border-[#B9D8CC] bg-white p-8 text-center shadow-[0_14px_34px_rgba(31,111,95,0.08)]">
          <p className="text-lg font-extrabold text-[#18332D]">Portfolio unavailable</p>
          <p className="mt-2 text-sm font-bold text-red-600">{portfolioError}</p>
        </section>
      </main>
    );
  }

  return (
    <main className="min-h-[calc(100vh-4rem)] px-4 py-7 sm:px-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <PortfolioHeader portfolio={portfolio} username={username} isOwnPortfolio={isOwnPortfolio} />
        <PortfolioStats portfolio={portfolio} />
        <PortfolioContactLine portfolio={portfolio} />
        <PortfolioAbout portfolio={portfolio} />
        <PortfolioRepositoryList repositories={portfolio?.repositories || []} />
        <PortfolioSkillGroups skillGroups={portfolio?.skillGroups || []} />
      </div>
    </main>
  );
}

function PortfolioContactLine({ portfolio }) {
  const hasContact =
    portfolio?.location ||
    portfolio?.githubUrl ||
    portfolio?.linkedinUrl ||
    portfolio?.personalWebsiteUrl ||
    portfolio?.publicEmail;

  if (!hasContact) return null;

  return (
    <section className="rounded-lg border border-[#B9D8CC] bg-white p-4 shadow-[0_14px_34px_rgba(31,111,95,0.08)]">
      <div className="flex flex-wrap items-center gap-2">
        {portfolio?.location && (
          <InfoPill icon={<MapPin size={14} />} label={portfolio.location} />
        )}

        {portfolio?.githubUrl && (
          <ExternalPill href={portfolio.githubUrl} icon={<FaGithub size={14} />} label="GitHub" />
        )}

        {portfolio?.linkedinUrl && (
          <ExternalPill href={portfolio.linkedinUrl} icon={<FaLinkedin size={14} />} label="LinkedIn" />
        )}

        {portfolio?.personalWebsiteUrl && (
          <ExternalPill href={portfolio.personalWebsiteUrl} icon={<Globe2 size={14} />} label="Website" />
        )}

        {portfolio?.publicEmail && (
          <ExternalPill href={`mailto:${portfolio.publicEmail}`} icon={<Mail size={14} />} label="Email" />
        )}
      </div>
    </section>
  );
}

function InfoPill({ icon, label }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-lg border border-[#B9D8CC] bg-[#F7F1E8] px-3 py-2 text-xs font-extrabold text-[#18332D]">
      {icon}
      {label}
    </span>
  );
}

function ExternalPill({ href, icon, label }) {
  return (
    <a
      href={href}
      target={href.startsWith("mailto:") ? undefined : "_blank"}
      rel="noreferrer"
      className="inline-flex items-center gap-1.5 rounded-lg border border-[#B9D8CC] bg-white px-3 py-2 text-xs font-extrabold text-[#18332D] transition hover:border-[#6FCF97] hover:bg-[#6FCF97]/25 hover:text-[#1F6F5F]"
    >
      {icon}
      {label}
    </a>
  );
}
